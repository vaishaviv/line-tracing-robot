import numpy as np
import itertools

class Vtx(object):
    def __init__(self, name, x, y):
        self.name=name
        self.x=x
        self.y=y
    def getName(self):
        return self.name
    def __str__(self):
        return self.name + '('+str(self.x) +','+ str(self.y) + ')'
    def __repr__(self):
        return self.__str__()

class Edge:
    def __init__(self, x1, y1, x2, y2):
        # Initialize the coordinates of the edge
        self.x1 = x1
        self.y1 = y1
        self.x2 = x2
        self.y2 = y2

    def __str__(self):
        # Return a string representation of the edge
        return f"Edge(({self.x1}, {self.y1}), ({self.x2}, {self.y2}))"

    def __repr__(self):
        # Return a string representation suitable for debugging
        return self.__str__()

t_0= 1.1 # extra time taken to turn 90 degree
t_B= 1.3# extra time taken to travel on broken line B
t_T= 1.2 #  extra time taken to travel on thin line T
t_N=float('inf')# extra time taken to travel on no line N

class Obs:
    def __init__(self, edge, type):
        if not isinstance(edge, Edge) or not isinstance(type, str):
            raise ValueError("edge must be an Edge object and type must be a string.")

        self.edge = edge
        self.type = type # type of obstacle B: broken line, T: thin line, N: no line

        # Assign v based on the type
        if type == "B":
            self.value = t_B
        elif type == "T":
            self.value = t_T
        elif type == "N":
            self.value = t_N

    def __str__(self):
        return f"Obs({self.edge}, type={self.type}, v={self.value})"

    def __repr__(self):
        return self.__str__()

    def get_edge(self):
        return self.edge

    def get_type(self):
        return self.type

    def get_value(self):
        return self.value

# Initialize an empty list for Obs objects
obslist = []

# Open the file in read mode
with open('obs_data.txt', 'r') as file:
    # Check if the file is empty
    first_line = file.readline().strip()

    if first_line:  # If the first line is not empty, continue processing
        # Reset the file pointer to the beginning
        file.seek(0)

        for line in file:
            parts = line.split()
            # Extract the coordinates and the float value
            x1 = float(parts[0])
            y1 = float(parts[1])
            x2 = float(parts[2])
            y2 = float(parts[3])
            type = parts[4]

            # Create an Edge object
            edge = Edge(x1, y1, x2, y2)

            # Create an Obs object
            obs = Obs(edge, type)

            # Append the Obs object to the list
            obslist.append(obs)
        #Print the obslist to verify
        print('The obstacles are ')
        for obs in obslist:
            print(obs)
    else:
        print("The file is empty. No obstacles.")



vtxlist = []

with open('verticescomp.txt', 'r') as file: #input the vertices by reading a file
    for line in file:
        # Split the line into name, x, and y parts
        parts = line.split()
        name = parts[0]
        x = float(parts[1])
        y = float(parts[2])

        # Create a Vtx object and add it to the list
        vertex = Vtx(name, x, y)
        vtxlist.append(vertex)

n=len(vtxlist)
print()
print('The vertices are ')
for vtx in vtxlist:
    print(vtx)

def dist(a, b):
    distance = abs(a.x - b.x) + abs(a.y - b.y)

    # Check for obstacles between points a and b
    for obs in obslist:
        edge = obs.get_edge()

        # Check if the edge is vertical and intersects with the y-coordinates of a and b
        if (edge.x1 == edge.x2 and edge.x1 == a.x and 
            min(a.y, b.y) <= edge.y1 <= max(a.y, b.y)):

            if obs.get_type() == "N":
                # Calculate detour distance
                detour_distance = (abs(a.x - edge.x1) + abs(a.y - edge.y1) + 
                                   abs(b.x - edge.x1) + abs(b.y - edge.y1))
                return detour_distance
            distance += obs.get_value()
        
        # Check if the edge is horizontal and intersects with the x-coordinates of a and b
        elif (edge.y1 == edge.y2 and edge.y1 == a.y and 
              min(a.x, b.x) <= edge.x1 <= max(a.x, b.x)):
            if obs.get_type() == "N":
                # Calculate L-shaped detour distance
                detour_distance = (abs(a.x - edge.x1) + abs(a.y - edge.y1) + 
                                   abs(b.x - edge.x1) + abs(b.y - edge.y1))
                return detour_distance  # Return the L-shaped detour distance
            distance += obs.get_value()

    return distance

Dmatrix = np.zeros((n, n))
for i in range(n):
    for j in range(n):
        Dmatrix[i][j]=dist(vtxlist[i],vtxlist[j])
print(Dmatrix[2][3])
print(vtxlist[2],vtxlist[3])
                           
print()
print('The distance matrix is ')
print(Dmatrix)

# Generate all permutations of the vertices
permutations = list(itertools.permutations(vtxlist))

# Convert each tuple to a list
permutations_as_lists = [list(perm) for perm in permutations]
min_distance = float('inf')  # This is the shortest distance/time of the optimal loop
optimal_path = []  # This is the sequence of the vertices of the optimal loop

for perm in permutations:
    distance = 0
    # Calculate the distance for the current permutation
    for j in range(n - 1):
        distance += dist(perm[j], perm[j + 1])  # Use the dist function to get the distance between consecutive vertices

    # Add the distance to return to the starting vertex
    distance += dist(perm[-1], perm[0])  # Complete the loop by returning to the starting vertex

    if distance < min_distance:
        min_distance = distance 
        optimal_path = perm  # Update the optimal path with the current permutation

# Print the optimal path
print()
print('The optimal path is:')
for vertex in optimal_path:
    print(vertex.name, end='\n')
print(optimal_path[0].name)  #return to the starting vertex
print('with the total distance = ' + str(min_distance) + '.')



